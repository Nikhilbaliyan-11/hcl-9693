package com.hcl.hclassessment2.repository;

import com.hcl.hclassessment2.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {

    Optional<Cart> findByCustomerCustomerId(Long customerId);
}
