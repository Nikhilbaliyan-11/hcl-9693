package com.hcl.hclassessment2.Controller;

import com.hcl.hclassessment2.entity.CustomerOrder;
import com.hcl.hclassessment2.entity.Product;
import com.hcl.hclassessment2.Service.ShoppingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shopping")
public class ShoppingController {

    @Autowired
    private ShoppingService shoppingService;

    @GetMapping("/products")
    public ResponseEntity<List<Product>> browseProducts() {
        return ResponseEntity.ok(shoppingService.getAllProducts());
    }

    @PostMapping("/cart/add")
    public ResponseEntity<String> addToCart(
            @RequestParam Long customerId,
            @RequestParam Long productId,
            @RequestParam int quantity) {
        shoppingService.addProductToCart(customerId, productId, quantity);
        return ResponseEntity.ok("Product successfully added to cart!");
    }

    @PostMapping("/order/place")
    public ResponseEntity<CustomerOrder> placeOrder(@RequestParam Long customerId) {
        return ResponseEntity.ok(shoppingService.placeOrder(customerId));
    }

    @PutMapping("/order/cancel/{orderId}")
    public ResponseEntity<CustomerOrder> cancelOrder(@PathVariable Long orderId) {
        return ResponseEntity.ok(shoppingService.cancelOrder(orderId));
    }

    @GetMapping("/order/history")
    public ResponseEntity<List<CustomerOrder>> getOrderHistory(@RequestParam Long customerId) {
        return ResponseEntity.ok(shoppingService.getOrderHistory(customerId));
    }
}
