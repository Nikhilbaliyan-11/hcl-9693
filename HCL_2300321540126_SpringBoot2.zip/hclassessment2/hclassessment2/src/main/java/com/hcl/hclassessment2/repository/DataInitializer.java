package com.hcl.hclassessment2.repository;

import com.hcl.hclassessment2.entity.Cart;
import com.hcl.hclassessment2.entity.Customer;
import com.hcl.hclassessment2.entity.Product;
import com.hcl.hclassessment2.repository.CartRepository;
import com.hcl.hclassessment2.repository.CustomerRepository;
import com.hcl.hclassessment2.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initDatabase(
            CustomerRepository customerRepository,
            ProductRepository productRepository,
            CartRepository cartRepository) {
        return args -> {
            if (productRepository.count() == 0) {
                // 1. Create Sample Products
                Product laptop = new Product();
                laptop.setProductName("Gaming Laptop");
                laptop.setDescription("High performance RTX 4060 Laptop");
                laptop.setPrice(1200.00);
                laptop.setQuantity(10);
                laptop.setCategory("Electronics");
                productRepository.save(laptop);

                Product mouse = new Product();
                mouse.setProductName("Wireless Mouse");
                mouse.setDescription("Ergonomic multi-device mouse");
                mouse.setPrice(50.00);
                mouse.setQuantity(50);
                mouse.setCategory("Electronics");
                productRepository.save(mouse);

                System.out.println("--- SAMPLE PRODUCTS SEEDED ---");
            }

            if (customerRepository.count() == 0) {
                // 2. Create Sample Customer
                Customer customer = new Customer();
                customer.setCustomerName("John Doe");
                customer.setEmail("john.doe@example.com");
                customer.setPassword("securePassword123");
                customer.setMobile("9876543210");
                customer.setCity("New York");
                customer = customerRepository.save(customer);

                // 3. Initialize Empty Cart for Customer
                Cart cart = new Cart();
                cart.setCustomer(customer);
                cart.setCreatedDate(LocalDate.now());
                cartRepository.save(cart);

                System.out.println("--- SAMPLE CUSTOMER AND CART REGISTERED (Customer ID: " + customer.getCustomerId() + ") ---");
            }
        };
    }
}
